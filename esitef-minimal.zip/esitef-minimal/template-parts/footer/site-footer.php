<?php
/**
 * Site footer — ESITEF
 *
 * @package esitef-minimal
 */

if ( is_page_template( 'page-templates/page-login.php' ) ) {
	return;
}
?>
<footer class="esitef-footer" id="colophon" aria-label="<? esc_attr_e( 'Pie de página ESITEF', 'esitef-minimal' ); ?>">
  <div class="footer-card">
    <div class="footer-content">

      <div class="footer-top">
        <div class="footer-newsletter">
          <h3><? esc_html_e( 'Suscríbete a nuestro newsletter', 'esitef-minimal' ); ?></h3>
          <form class="footer-newsletter-form" action="#" method="post" onsubmit="return false;" aria-label="<? esc_attr_e( 'Formulario newsletter', 'esitef-minimal' ); ?>">
            <input type="email" id="footer-email-input" placeholder="nombre@email.com" aria-label="<? esc_attr_e( 'Tu email', 'esitef-minimal' ); ?>">
            <button type="submit"><? esc_html_e( 'Suscribirse', 'esitef-minimal' ); ?></button>
          </form>
        </div>

        <div class="footer-pages">
          <span class="footer-pages-label">
            <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4l8 8M12 4v8H4" stroke-linecap="round" stroke-linejoin="round"/></svg>
            <? esc_html_e( 'Páginas', 'esitef-minimal' ); ?>
          </span>
          <nav class="footer-pages-links" aria-label="<? esc_attr_e( 'Páginas del sitio', 'esitef-minimal' ); ?>">
            <?php
            if ( has_nav_menu( 'footer' ) ) {
              wp_nav_menu(
                array(
                  'theme_location' => 'footer',
                  'container'      => false,
                  'items_wrap'     => '%3$s',
                  'depth'          => 1,
                )
              );
            } else {
              ?>
              <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><? esc_html_e( 'Inicio', 'esitef-minimal' ); ?></a>
              <a href="<?php echo esc_url( home_url( '/la-escuela/' ) ); ?>"><? esc_html_e( 'La Escuela', 'esitef-minimal' ); ?></a>
              <a href="<?php echo esc_url( get_post_type_archive_link( 'courses' ) ?: home_url( '/courses/' ) ); ?>"><? esc_html_e( 'Formaciones', 'esitef-minimal' ); ?></a>
              <a href="<?php echo esc_url( home_url( '/contacto/' ) ); ?>"><? esc_html_e( 'Contacto', 'esitef-minimal' ); ?></a>
              <?php
            }
            ?>
          </nav>
        </div>
      </div>

      <div class="footer-bottom">
        <div class="footer-bottom-left">
          <div class="footer-social" aria-label="<? esc_attr_e( 'Redes sociales', 'esitef-minimal' ); ?>">
            <a href="https://www.instagram.com/esitef_oficial/" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
              <svg viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
            </a>
            <a href="https://www.linkedin.com/company/esitef/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
              <svg viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
            </a>
          </div>
          <a href="mailto:info@esitef.com" class="footer-email">info@esitef.com</a>
        </div>
        <p class="footer-copyright">
          <?php
          printf(
            /* translators: %s: year */
            esc_html__( 'Escuela ESITEF. Todos los derechos reservados. %s', 'esitef-minimal' ),
            esc_html( gmdate( 'Y' ) )
          );
          ?>
        </p>
      </div>

    </div>
  </div>
</footer>
