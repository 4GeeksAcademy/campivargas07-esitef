<?php
// presencial-ejemplo.html
?>
<!-- =====================================================
     HERO SECTION
     ===================================================== -->
  <section class="course-hero">
    <div class="hero-content">
      <span class="subtitle">Formación Presencial y Online</span>
      <h1>Programa activo de autonomía motriz y funcional en adultos mayores</h1>
      
      <div class="hero-meta">
        <article class="hero-meta-item">
          <div class="hero-meta-icon">
            <svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
          </div>
          <div class="hero-meta-body">
            <span class="hero-meta-value">17 y 31 de Octubre</span>
            <span class="hero-meta-label">8 hrs Online</span>
          </div>
        </article>
        <span class="hero-meta-sep" aria-hidden="true"></span>
        <article class="hero-meta-item">
          <div class="hero-meta-icon">
            <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
          </div>
          <div class="hero-meta-body">
            <span class="hero-meta-value">27 al 29 de Noviembre</span>
            <span class="hero-meta-label">Presencial</span>
          </div>
        </article>
        <span class="hero-meta-sep" aria-hidden="true"></span>
        <article class="hero-meta-item">
          <div class="hero-meta-icon">
            <svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
          </div>
          <div class="hero-meta-body">
            <span class="hero-meta-value">Córdoba (ARG)</span>
            <span class="hero-meta-label">Sede presencial</span>
          </div>
        </article>
      </div>

      <a href="#inscribirme" class="hero-btn">Inscribirme ahora</a>
    </div>

    <div class="hero-image">
      <!-- Imagen de ejemplo -->
      <img src="https://esitef.com/online/wp-content/uploads/2026/06/Programa-activo-de-autonomia-motriz-y-funcional-en-adultos-mayores-cba-2.jpg" alt="Adultos mayores en movimiento">
    </div>
  </section>

  <!-- =====================================================
     DATOS GENERALES & DESCRIPCIÓN (NUEVO DISEÑO GRID)
     ===================================================== -->
  <section class="course-details">
    
    <div class="mission-card">
      <div class="mission-main-text">
        La población mundial mayor de 60 años se duplicará para 2050, pero nuestra industria aún no está preparada. Existe una escasez crítica de espacios de entrenamiento diseñados específicamente para preservar la autonomía funcional de esta generación. Es el momento de cubrir esta brecha y liderar el cambio.
        <br>
        <br>
        Aquí tienes el sistema probado para convertir esta demanda en servicios grupales altamente rentables, construyendo comunidades con adherencia incondicional. Ganarás las herramientas estratégicas para evaluar con precisión, liderar con seguridad y elevar el estándar de tu práctica profesional.
      </div>
      <img src="https://esitef.com/online/wp-content/uploads/2026/06/Programa-activo-de-autonomia-motriz-y-funcional-en-adultos-mayores-3.jpg" alt="Entrenamiento" class="mission-img">
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
          </div>
          <h4>Ubicación</h4>
        </div>
        <p>Astrid Training Center<br>9 de Julio 424, Córdoba</p>
      </div>

      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>
          </div>
          <h4>Fechas</h4>
        </div>
        <p>4 hrs contenido asincrónico<br>4 hs contenido sincrónico 17 y 31 OCT<br>Presencial: 27, 28, 29 NOV</p>
      </div>

      <div class="stat-card">
        <div class="stat-top">
          <div class="stat-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <h4>Dirigido a</h4>
        </div>
        <p>Fisioterapeutas y estudiantes de los últimos años.</p>
      </div>

      <div class="stat-card">
        <div class="stat-top"> 
          <div class="stat-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/></svg>
          </div>
          <h4>Inversión</h4>
        </div>
        <p>Reserva: $100,000 ARS<br>+ Día del curso: $350 USD</p>
      </div>
    </div>

  </section>

  <!-- =====================================================
     PROGRAMA DEL CURSO (Acordeón)
     ===================================================== -->
  <section class="course-syllabus">
    <div class="syllabus-card">
      <div class="syllabus-bg" aria-hidden="true"></div>
      <div class="syllabus-inner">
    <div class="syllabus-left">
      <h2>Panorama general</h2>
      <p>Comprender el envejecimiento va mucho más allá de lo biológico; implica factores sociales, económicos y de vida. Conoce los pilares de esta nueva realidad:</p>
      <a href="#" class="syllabus-btn desktop-only-btn">
        Descargar PDF
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      </a>
    </div>

    <div class="accordion-container">

      <!-- Módulo 1 -->
      <div class="accordion-item">
        <button class="accordion-header" aria-expanded="false">
          5 Ejes de Trabajo
          <span class="accordion-icon">+</span>
        </button>
        <div class="accordion-content">
          <div class="accordion-content-inner">
            <ul style="padding-left: 20px; margin: 0; display: flex; flex-direction: column; gap: 6px;">
              <li>A) Entrenamiento Basal</li>
              <li>B) Manipulación de objetos</li>
              <li>C) Movimiento expresivo, rítmico y creativo</li>
              <li>D) Conciencia somática/Inteligencia biológica</li>
              <li>E) Comunidad, relación con el entorno y naturaleza</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Módulo 2 -->
      <div class="accordion-item">
        <button class="accordion-header" aria-expanded="false">
          Contenido Online (8 hrs)
          <span class="accordion-icon">+</span>
        </button>
        <div class="accordion-content">
          <div class="accordion-content-inner">
            <ul style="padding-left: 20px; margin: 0; display: flex; flex-direction: column; gap: 6px;">
              <li>Panorama actual de la adultez</li>
              <li>Valoración estructural VS conocer la red de la persona</li>
              <li>Sistema de Movimiento Humano</li>
              <li>Aprendizaje Motor</li>
              <li>Cambios en la estructura y función muscular asociados al envejecimiento</li>
              <li>Valoración del Adulto Mayor</li>
              <li>Presentación del programa +65</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Módulo 3 -->
      <div class="accordion-item">
        <button class="accordion-header" aria-expanded="false">
          Contenido Presencial (20 hrs)
          <span class="accordion-icon">+</span>
        </button>
        <div class="accordion-content">
          <div class="accordion-content-inner">
            <ul style="padding-left: 20px; margin: 0; display: flex; flex-direction: column; gap: 6px;">
              <li>Elementos prácticos para el armado de clases</li>
              <li>Entrenamiento basal</li>
              <li>Manipulación de objetos</li>
              <li>Movimiento expresivo, rítmico y creativo</li>
              <li>Conciencia somática e Inteligencia Biológica</li>
              <li>Transferencia del trabajo en sala al contexto natural y de “calle”</li>
              <li>Creación de Comunidad</li>
            </ul>
          </div>
        </div>
      </div>

    </div>

    <!-- Botón visible solo en mobile -->
    <a href="#" class="syllabus-btn mobile-only-btn">
      Descargar PDF
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
    </a>
      </div>
    </div>
  </section>

  <!-- =====================================================
     DOCENTES (Cascada Innovadora)
     ===================================================== -->
  <section class="teachers-section">
    <h2>Docentes de la Formación</h2>
    <div class="teachers-grid-cascada">
      <!-- Docente 1 -->
      <div class="teacher-card">
        <div class="teacher-avatar-corner">
          <img src="https://esitef.com/online/wp-content/uploads/2026/06/Noelia_Martinez.jpg" alt="Noelia Martínez">
        </div>
        
        <h3>Noelia Martínez</h3>
        <span class="teacher-role">ARG</span>
        
        <div class="teacher-bio">
          <ul>
            <li>Fundadora y coordinadora de NUTA</li>
            <li>Formada, desde hace más de 20 años en diversos métodos de trabajo postural y variadas disciplinas de movimiento (Feldenkrais, Flying Low, Contact Impro, Movimiento Eficiente, Ejercicio Terapéutico, JEMS Method, Feldekrais, Rpg, GDS, SGA, entre otros)…</li>
            <li>Maestría en Salud: Entrenamiento, nutrición y descanso (España)</li>
            <li>Co-creadora del Formato de Entrenamiento Nuta y E.N +65. Prácticas que surgen del cruce entre diferentes artes del movimiento y las Ciencias de la Salud. Son propuestas fuertemente inclusivas y adaptadas a todas las edades y condiciones físicas (Todos los cuerpos, todas las edades, todos los movimientos)</li>
            <li>Mamá de dos varones, disfruto tanto de enseñar como aprender, viajo cada vez que puedo y disfruto enormemente vivir en Mendoza – Argentina.</li>
          </ul>
        </div>
      </div>

      <!-- Docente 3 -->
      <div class="teacher-card">
        <div class="teacher-avatar-corner">
          <img src="https://esitef.com/online/wp-content/uploads/2026/06/Tomas_Bonino.jpg" alt="Tomás Bonino">
        </div>
        
        <h3>Tomás Bonino</h3>
        <span class="teacher-role">ESP</span>
        
        <div class="teacher-bio">
          <ul>
            <li>Fisioterapeuta en España desde 2001.</li>
            <li>Movement coach . Experto en movimiento terapéutico.</li>
            <li>Pionero de la Pedagogía aplicada al aprendizaje motor</li>
            <li>Asesor clínico y colaborador en hospitales, clínicas, equipos y jugadores PRO, ballets, circos y artistas escénicos PRO en 12 paises.</li>
            <li>Docente en cientos de formaciones y congresos internacionales en 12 paises.</li>
            <li>Autor de “Fisioterapia desde y para el movimiento . 2022” , "DOLOR. Conceptos esenciales para fisioterapeutas (y pacientes)" 2024 y “69 ideas desde la evidencia para la práctica clínica de los fisioterapeutas” 2026</li>
            <li>Autor de diversos artículos científicos...</li>
            <li>Investigador-colaborador en "InBody_Lab" ( U. Carlos III. España ) y "Neurocognition & action" ( U. Bielefeld. Alemania )</li>
            <li>Curioso empedernido, emprendedor multifacético, pensador ecléctico y viajero</li>
          </ul>
        </div>
      </div>

      <!-- Docente 2 -->
      <div class="teacher-card">
        <div class="teacher-avatar-corner">
          <img src="https://esitef.com/online/wp-content/uploads/2026/06/Matias_Sampietro.jpg" alt="Matías Sampietro">
        </div>
        
        <h3>Matías Sampietro</h3>
        <span class="teacher-role">ARG</span>
        
        <div class="teacher-bio">
          <ul>
            <li>Doctorando en Ciencias de la Salud.</li>
            <li>Especialista en Fisioterpia deportiva</li>
            <li>Master en Prevencion y Readaptacion de lesiones</li>
            <li>CEO y fundador de Equipophysical-Staff Docente Esitef internacional</li>
            <li>Coordinador Academico Maestria en Reentrenamiento y Prevencion de lesiones (UGR)</li>
            <li>Ex jefe del departamento de rehabilitacion Club Atletico Belgrano</li>
            <li>Speaker en múltiples congresos y cursos internacionales</li>
            <li>Docente e Investigador asociado (UNRAF)</li>
          </ul>
        </div>
      </div>

    </div>
  </section>
